-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Окт 24 2018 г., 17:11
-- Версия сервера: 10.1.36-MariaDB
-- Версия PHP: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `kino`
--

-- --------------------------------------------------------

--
-- Структура таблицы `toms`
--

CREATE TABLE `toms` (
  `id` int(11) NOT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `phoneNumber` varchar(255) DEFAULT NULL,
  `status` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `toms`
--

INSERT INTO `toms` (`id`, `firstName`, `lastName`, `phoneNumber`, `status`) VALUES
(1, NULL, NULL, NULL, 0),
(2, NULL, NULL, NULL, 0),
(3, NULL, NULL, NULL, 0),
(4, NULL, NULL, NULL, 0),
(5, NULL, NULL, NULL, 0),
(6, NULL, NULL, NULL, 0),
(7, NULL, NULL, NULL, 0),
(8, NULL, NULL, NULL, 0),
(9, NULL, NULL, NULL, 0),
(10, NULL, NULL, NULL, 0),
(11, NULL, NULL, NULL, 0),
(12, NULL, NULL, NULL, 0),
(13, NULL, NULL, NULL, 0),
(14, NULL, NULL, NULL, 0),
(15, NULL, NULL, NULL, 0),
(16, NULL, NULL, NULL, 0),
(17, NULL, NULL, NULL, 0),
(18, NULL, NULL, NULL, 0),
(19, NULL, NULL, NULL, 0),
(20, NULL, NULL, NULL, 0),
(21, NULL, NULL, NULL, 0),
(22, NULL, NULL, NULL, 0),
(23, NULL, NULL, NULL, 0),
(24, NULL, NULL, NULL, 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `toms`
--
ALTER TABLE `toms`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `toms`
--
ALTER TABLE `toms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
